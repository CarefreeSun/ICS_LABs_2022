/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_236()
{
    return 3281031256U;
}

void setval_328(unsigned *p)
{
    *p = 2462550344U;
}

void setval_436(unsigned *p)
{
    *p = 3251079496U;
}

void setval_297(unsigned *p)
{
    *p = 2425393752U;
}

unsigned getval_100()
{
    return 2425393752U;
}

unsigned addval_497(unsigned x)
{
    return x + 2428995912U;
}

void setval_237(unsigned *p)
{
    *p = 3277383745U;
}

void setval_319(unsigned *p)
{
    *p = 3347663085U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_420(unsigned x)
{
    return x + 2446756315U;
}

unsigned addval_496(unsigned x)
{
    return x + 3229925785U;
}

unsigned addval_384(unsigned x)
{
    return x + 3526937225U;
}

unsigned addval_440(unsigned x)
{
    return x + 3223374473U;
}

unsigned addval_308(unsigned x)
{
    return x + 3221804673U;
}

unsigned addval_387(unsigned x)
{
    return x + 3675832713U;
}

unsigned addval_275(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_155()
{
    return 3229925769U;
}

unsigned getval_189()
{
    return 3374367115U;
}

unsigned getval_165()
{
    return 3590974797U;
}

void setval_215(unsigned *p)
{
    *p = 2425411209U;
}

void setval_438(unsigned *p)
{
    *p = 2430634316U;
}

unsigned addval_247(unsigned x)
{
    return x + 1254343049U;
}

void setval_310(unsigned *p)
{
    *p = 3525367433U;
}

unsigned getval_142()
{
    return 3381971593U;
}

unsigned getval_216()
{
    return 2429208967U;
}

unsigned getval_203()
{
    return 3286272344U;
}

unsigned addval_478(unsigned x)
{
    return x + 2445379844U;
}

unsigned addval_371(unsigned x)
{
    return x + 3224426121U;
}

unsigned addval_239(unsigned x)
{
    return x + 3223377537U;
}

unsigned addval_449(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_191(unsigned x)
{
    return x + 3526940329U;
}

unsigned addval_229(unsigned x)
{
    return x + 3677932041U;
}

unsigned addval_223(unsigned x)
{
    return x + 3238656076U;
}

void setval_141(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_400()
{
    return 2464188744U;
}

unsigned getval_219()
{
    return 3286272328U;
}

unsigned addval_429(unsigned x)
{
    return x + 3678980745U;
}

unsigned getval_211()
{
    return 3227566473U;
}

unsigned getval_404()
{
    return 2462747109U;
}

unsigned addval_454(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_119(unsigned x)
{
    return x + 3281046157U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
